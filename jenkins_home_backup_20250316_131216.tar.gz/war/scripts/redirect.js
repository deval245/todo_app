let scriptTag = document.getElementById("redirect");
let redirectUrl = scriptTag.dataset.redirectUrl;
window.location.replace(redirectUrl);
